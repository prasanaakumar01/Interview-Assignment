package Testcase;
import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObjects.HomePagePageObject;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
public class HomePageTestcase
{
	@Test
	//protected static Properties properties = null;
	public static void Execute() throws IOException, InterruptedException 
	{
    
    System.setProperty("webdriver.http.factory", "jdk-http-client");
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://nbyula.com/");
	driver.manage().window().maximize();
	Thread.sleep(8000);
	PageFactory.initElements(driver,HomePagePageObject.class);
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	jse.executeScript("window.scrollBy(0,250)");
	HomePagePageObject.Study_Abroad.click();
	Thread.sleep(5000);
    String S1 = HomePagePageObject.Study_Abroad_Full_Options.getText();
    System.out.println("The Study Board Options are:" +S1 );
	Thread.sleep(5000);
	HomePagePageObject.Work_Abroad.click();
	Thread.sleep(5000);
	String S2 = HomePagePageObject.Work_Abroad_Full_Options.getText();
    System.out.println("The Work Board Options are:" +S2 );
    Thread.sleep(5000);
	HomePagePageObject.Language_Preparation.click();
	Thread.sleep(5000);
	String S3 = HomePagePageObject.Language_Preparation_Full_OPtions.getText();
    System.out.println("The Language Preparation Options are:" +S3 );
    Thread.sleep(5000);
	HomePagePageObject.Education_Financing.click();
	Thread.sleep(5000);
	String S4 = HomePagePageObject.Education_Financing_Full_options.getText();
    System.out.println("The Education Financing Options are:" +S4 );
    Thread.sleep(5000);
	HomePagePageObject.Visa_Migration.click();
	Thread.sleep(5000);
	String S5 = HomePagePageObject.Visa_Migration_FullOptions.getText();
    System.out.println("The Visa Migration Options are:" +S5 );
    Thread.sleep(5000);
	HomePagePageObject.Post_Landing_Support.click();
	Thread.sleep(5000);
	String S6 = HomePagePageObject.Post_Landing_Support_Full_Options.getText();
    System.out.println("The Post Landing Support Options are:" +S6 );

	
}
}