package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePagePageObject
{
	public static WebDriver driver=null;

	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[1]/div[1]/a") 
	public static WebElement Study_Abroad;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[1]/div[2]/div/ul") 
	public static WebElement Study_Abroad_Full_Options;
	
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[2]/div[1]/a") 
	public static WebElement Work_Abroad;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[2]/div[2]/div") 
	public static WebElement Work_Abroad_Full_Options;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[3]/div[1]/a") 
	public static WebElement Language_Preparation;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[3]/div[2]/div") 
	public static WebElement Language_Preparation_Full_OPtions;
	
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[4]/div[1]/a") 
	public static WebElement Education_Financing;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[4]/div[2]/div") 
	public static WebElement Education_Financing_Full_options;
	
	//*[@id="_category-navigation-bar"]/div/div/div[2]/div[5]/div[2]/div
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[5]/div[1]/a") 
	public static WebElement Visa_Migration;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[5]/div[2]/div") 
	public static WebElement Visa_Migration_FullOptions;
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[6]/div[1]/a") 
	public static WebElement Post_Landing_Support;
	
	
	@FindBy(xpath="//*[@id=\"_category-navigation-bar\"]/div/div/div[2]/div[6]/div[2]/div") 
	public static WebElement Post_Landing_Support_Full_Options;
	
	
}
